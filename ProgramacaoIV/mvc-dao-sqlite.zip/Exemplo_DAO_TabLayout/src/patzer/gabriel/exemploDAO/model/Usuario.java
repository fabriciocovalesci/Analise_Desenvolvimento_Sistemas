package patzer.gabriel.exemploDAO.model;

import patzer.gabriel.exemploDAO.model.database.DAO_Usuario;

public class Usuario {
    private Integer id;
    private String nome;
    private String email;
    private String senha;
    private byte[] salt;

    @Override
    public String toString() {
        return "Usuário{" + id + ": " +
                "nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                ", salt='" + salt.toString() + '\'' +
                '}';
    }

    public Usuario() {
    }

    public byte[] getSalt() {
        return salt;
    }

    public void setSalt(byte[] salt) {
        this.salt = salt;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Usuario(String nome, String email, String senha, byte[] salt) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.salt = salt;
    }

    public void salvar (){
        DAO_Usuario du = new DAO_Usuario();
        du.create(this);
    }

    public void atualizar (){
        DAO_Usuario du = new DAO_Usuario();
        du.update(this);
    }

    public void excluir (){
        DAO_Usuario du = new DAO_Usuario();
        du.remove(this);
    }
}
