package patzer.gabriel.exemploDAO.model.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {

    public static Connection connection;

    public Connection conectar(){
        if (connection != null) {
            return connection;
        }
        else{
            try {
                connection = DriverManager.getConnection("jdbc:sqlite:src/patzer/gabriel/exemploDAO/model/database/exemplodao-usuario.db");
                System.out.println("Conexão ao banco estabelecida.");
            } catch (SQLException e) {
                System.err.println("Não foi possível conectar ao banco de dados.");
            }
            return connection;
        }
    }

    public void desconectar(){
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Falha ao encerrar conexão com o banco.");
            }
            connection = null;
        }
    }
}