package patzer.gabriel.exemploDAO.model.database;

import patzer.gabriel.exemploDAO.model.Usuario;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

public class DAO_Usuario extends DBUtils {
    private final boolean LIMPAR_TABELA = false;

    public DAO_Usuario(){
        conectar();
        try {
            if (LIMPAR_TABELA){
                PreparedStatement stm = connection.prepareStatement("DROP TABLE IF EXISTS Users;");
                stm.executeUpdate();
                stm.close();
            }
            PreparedStatement stm = connection.prepareStatement("CREATE TABLE IF NOT EXISTS Users(" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nome TEXT," +
                    "email TEXT," +
                    "senha TEXT," +
                    "salt TEXT);");
            stm.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Falha ao criar tabela de prdutos.");
            e.printStackTrace();
        }
    }

    public void create(Usuario usuario) {
        conectar();
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement("INSERT INTO" +
                    " Users(_id,nome,email,senha,salt)" +
                    " VALUES(?,?,?,?,?);");
            if (usuario.getId() != null){
                statement.setInt(1, usuario.getId());
            } else {
                statement.setNull(1, Types.INTEGER);
            }
            statement.setString(2, usuario.getNome());
            statement.setString(3, usuario.getEmail());
            statement.setString(4, usuario.getSenha());
            statement.setBytes(5, usuario.getSalt());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Não foi possível inserir novo Usuario no banco.");
            e.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            desconectar();
        }
    }

    public void update(Usuario usuario) {
        conectar();
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE Users " +
                    "SET nome = ?, email = ?, senha = ?, salt = ? " +
                    "WHERE _id = ?");
            statement.setString(1, usuario.getNome());
            statement.setString(2, usuario.getEmail());
            statement.setString(3, usuario.getSenha());
            statement.setBytes(4, usuario.getSalt());
            statement.setInt(5, usuario.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Não foi possível alterar dados do Usuario no banco.");
        }finally {
            desconectar();
        }
    }

    public void remove(int id) {
        conectar();
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement("DELETE FROM Users WHERE _id=?;");
            statement.setInt(1,id);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Falha ao remove elemento no banco.");
        }finally {
            desconectar();
        }
    }

    public void remove (String nome){
        conectar();
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement("DELETE FROM Users WHERE nome=?;");
            statement.setString(1,nome);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Falha ao remove elemento no banco.");
        }finally {
            desconectar();
        }
    }

    public void remove (Usuario usuario){
        remove(usuario.getId());
    }

    public ArrayList<Usuario> readAll(){
        conectar();
        ArrayList<Usuario> lista = new ArrayList<>();
        ResultSet resultSet = null;
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement("SELECT * FROM Users;");
            resultSet = statement.executeQuery();

            if (resultSet.next() == false) {
                System.out.println("Nenhum dado encontrado.");
            }else{
                do{
                    Usuario usuario = new Usuario();
                    usuario.setId(resultSet.getInt("_id"));
                    usuario.setNome(resultSet.getString("nome"));
                    usuario.setEmail(resultSet.getString("email"));
                    usuario.setSenha(resultSet.getString("senha"));
                    usuario.setSalt(resultSet.getBytes("salt"));
                    lista.add(usuario);
                }while(resultSet.next());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Não foi possível realizar a consulta no banco.");
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            desconectar();
        }
        return lista;
    }

    public Usuario read(int id){
        conectar();
        Usuario usuario = null;
        ResultSet resultSet = null;
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement("SELECT * FROM Users WHERE _id=?;");
            statement.setInt(1,id);
            resultSet = statement.executeQuery();

            if (resultSet.next() == false) {
                System.out.println("Nenhum dado encontrado.");
            }else{
                usuario = new Usuario();
                usuario.setId(resultSet.getInt("_id"));
                usuario.setNome(resultSet.getString("nome"));
                usuario.setEmail(resultSet.getString("email"));
                usuario.setSenha(resultSet.getString("senha"));
                usuario.setSenha(resultSet.getString("salt"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Não foi possível realizar a consulta no banco.");
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            desconectar();
        }
        return usuario;
    }

    public Usuario read(String email){
        conectar();
        Usuario usuario = null;
        ResultSet resultSet = null;
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement("SELECT * FROM Users WHERE email=?;");
            statement.setString(1,email);
            resultSet = statement.executeQuery();

            if (resultSet.next() == false) {
                System.out.println("Nenhum dado encontrado.");
            }else{
                usuario = new Usuario();
                usuario.setId(resultSet.getInt("_id"));
                usuario.setNome(resultSet.getString("nome"));
                usuario.setEmail(resultSet.getString("email"));
                usuario.setSenha(resultSet.getString("senha"));
                usuario.setSalt(resultSet.getBytes("salt"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Não foi possível realizar a consulta no banco.");
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    //ignore
                }
            }
            desconectar();
        }
        return usuario;
    }
}
