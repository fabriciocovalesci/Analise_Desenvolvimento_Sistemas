package patzer.gabriel.exemploDAO;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import patzer.gabriel.exemploDAO.model.PasswordUtils;
import patzer.gabriel.exemploDAO.model.Usuario;

import java.security.NoSuchAlgorithmException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("view/sample.fxml"));
        primaryStage.setTitle("Exemplo DAO - Tab");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);

        //teste sqlite crypt+salt
//        String email = "admin";
//        String senha = "admin";
//        Usuario usuario = new Usuario();
//        usuario.setEmail(email);
//        byte [] salt=null;
//        try {
//            salt = PasswordUtils.getSalt();
//        } catch (NoSuchAlgorithmException e) {
//            System.out.println("Erro de algoritmo de salt");
//        }
//        usuario.setSalt(salt);
//        usuario.setSenha(PasswordUtils.getSecurePassword(senha,salt));
//        usuario.setNome("Administrador");
//        System.out.printf(usuario.toString());
//
//        usuario.salvar();
    }
}
