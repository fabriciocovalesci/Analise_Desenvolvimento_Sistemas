package patzer.gabriel.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import patzer.gabriel.model.Item;

public class MenuController {
    private Item item;

    @FXML
    private Label lblNome ;

    @FXML
    private Label lblPreco ;

    public void setMenuItem(Item item) {
        this.item = item ;
        lblPreco.textProperty().unbind();
        if (item == null) {
            lblNome.setText(null);
            lblPreco.setText(null);
        } else {
            lblNome.setText(item.getNome());
            lblPreco.textProperty().bind(item.precoProperty().asString("Preço: $%.2f"));
        }
    }
}
