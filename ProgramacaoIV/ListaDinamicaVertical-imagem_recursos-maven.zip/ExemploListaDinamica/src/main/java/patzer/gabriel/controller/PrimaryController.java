package patzer.gabriel.controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;
import patzer.gabriel.model.Item;

public class PrimaryController {

    @FXML
    private Label precoFinal;

    @FXML
    private ListView<Item> myListView;

    @FXML
    private Button btnAdd;
    private double soma;

    @FXML
    void addItem(ActionEvent event) {
        double val = myListView.getSelectionModel().getSelectedItem().getPreco();
        soma += val;
        updatePreco();
    }

    // método chamado automaticamente ao carregar o controller
    public void initialize() {
        myListView.setCellFactory(itemListView -> new ItemListCell());

        for (int i = 0; i < 50; i++) {
            String nome = "item "+ (i+1);
            double val = Math.random()*100;
            Item item = new Item(nome, val);
            myListView.getItems().add(item);
        }

        myListView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                System.out.println("eu poderia ser o evento de adicionar item. pode ser problemático em mobile.");
                System.out.println("clicked on " + myListView.getSelectionModel().getSelectedItem().getNome());
                System.out.println("Preço: " + myListView.getSelectionModel().getSelectedItem().getPreco());
            }
        });


        this.soma = 0.0;
        updatePreco();
    }

    private void updatePreco() {
        precoFinal.setText(String.format("Preço: R$ %.2f",soma));
    }
}
