package patzer.gabriel.controller;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import patzer.gabriel.App;
import patzer.gabriel.model.Item;

public class PrimaryController {

    @FXML
    private Label precoFinal;

    @FXML
    private ImageView mainLogo;

    @FXML
    private ListView<Item> myListView;

    private static double soma;
    private static Label precoStatic;

    // Controle bem mal feito para mostrar a interação entrew dois controllers
    // Seria necessário manter uma lista de cada item adicionado, talvez até mostrando
    //quantos de cada estão na lista.
    public static void removeItem(Item item) {
        soma -= item.getPreco();
        updatePreco();
    }

    public static void addItem(Item item) {
        soma += item.getPreco();
        updatePreco();
    }

    // método chamado automaticamente ao carregar o controller
    public void initialize() {
        mainLogo.setImage(new Image(App.class.getResourceAsStream("images/lanche-logo.png")));

        // criar lista a partir de DAO ou outra fonte, imagens agora em URL (menos eficiente, muda a forma de carregar imagem)
        Item i1 = new Item("Pão de Queijo",3.5,"https://img.estadao.com.br/thumbs/640/resources/jpg/3/4/1571767934443.jpg");
        Item i2 = new Item("Baguete",5.5,"https://s2.glbimg.com/o4EE54pXbrQCwJxUu-JzBUJWAA0=/0x0:960x720/984x0/smart/filters:strip_icc()/s.glbimg.com/po/rc/media/2014/08/24/13_28_17_37_931323_1376234769256950_1078625022_n.jpg");
        Item i3 = new Item("Pastel",7,"https://cozinhatecnica.com/wp-content/uploads/2019/11/massa-de-pastel.jpg");
        Item i4 = new Item("Coxinha",3,"https://static.clubedaanamariabraga.com.br/wp-content/uploads/2019/03/coxinha-pratica-scaled.jpg");

        myListView.getItems().add(i1);
        myListView.getItems().add(i2);
        myListView.getItems().add(i3);
        myListView.getItems().add(i4);

        myListView.setCellFactory(itemListView -> new ItemListCell());

        this.soma = 0.0;
        precoStatic = precoFinal;
        updatePreco();
    }

    private static void updatePreco() {
        precoStatic.setText(String.format("Preço: R$ %.2f",soma));
    }
}
