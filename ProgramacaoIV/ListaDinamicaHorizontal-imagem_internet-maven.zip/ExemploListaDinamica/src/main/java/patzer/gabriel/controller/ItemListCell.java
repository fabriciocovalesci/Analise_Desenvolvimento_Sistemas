package patzer.gabriel.controller;

import javafx.fxml.FXMLLoader;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Pane;
import patzer.gabriel.App;
import patzer.gabriel.model.Item;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UncheckedIOException;

public class ItemListCell extends ListCell<Item> {
    private final Pane itemView;
    private final MenuController menuController;

    public ItemListCell() {
        try {
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("item.fxml"));
            FXMLLoader loader = new FXMLLoader(App.class.getResource("item.fxml"));
            itemView = loader.load();
            menuController = loader.getController();
            setGraphic(itemView);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        } catch (IOException exc) {
            // IOException here is fatal:
            throw new UncheckedIOException(exc);
        }

    }

    @Override
    protected void updateItem(Item item, boolean empty) {
        super.updateItem(item, empty);
        try {
            menuController.setMenuItem(item);
        } catch (FileNotFoundException e) {
            System.err.println("Erro ao carregar imagem.");
//            e.printStackTrace();
        }
    }
}

