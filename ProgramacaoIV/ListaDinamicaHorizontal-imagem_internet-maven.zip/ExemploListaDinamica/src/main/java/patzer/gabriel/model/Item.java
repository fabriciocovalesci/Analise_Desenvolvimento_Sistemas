package patzer.gabriel.model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

public class Item {
    private final String nome ;
    private final DoubleProperty preco = new SimpleDoubleProperty() ;
    private final String imageURL;

    public String getImageURL() {
        return imageURL;
    }

    public Item(String nome, double preco, String imageURL) {
        this.nome = nome;
        this.imageURL = imageURL;
        setPreco(preco);
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco.get();
    }

    public DoubleProperty precoProperty() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco.set(preco);
    }
}
