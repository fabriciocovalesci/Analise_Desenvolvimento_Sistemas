package patzer.gabriel.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import patzer.gabriel.App;
import patzer.gabriel.model.Item;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class MenuController {

    private Item item;

    @FXML
    private ImageView myPhoto;

    @FXML
    private Label myName;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnRemove;

    // Interação entre os dois controllers (este, de cada item, e PrimaryController)
    @FXML
    void addThisItem(ActionEvent event) {
        PrimaryController.addItem(item);
    }

    @FXML
    void removeThisItem(ActionEvent event) {
        PrimaryController.removeItem(item);
    }

    public void setMenuItem(Item item) throws FileNotFoundException {
        this.item = item ;
        myName.textProperty().unbind();
        myPhoto.imageProperty().unbind();
        if (item == null) {
            myName.setText(null);
            myPhoto.setImage(null);
        } else {
            myName.setText(item.getNome());
            // para carregar da internet não pode ser stream, basta a URL.
            // é possível combinar ambas as formas com try-catch de acordo com o tipo de exceção
            Image i = new Image(item.getImageURL());
            myPhoto.setImage(i);
        }
    }
}
