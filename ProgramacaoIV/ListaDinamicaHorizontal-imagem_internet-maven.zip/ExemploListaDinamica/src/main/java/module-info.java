module patzer.gabriel {
    requires javafx.controls;
    requires javafx.fxml;

    opens patzer.gabriel to javafx.fxml;
    opens patzer.gabriel.controller to javafx.fxml;
    opens patzer.gabriel.model to javafx.fxml;
    exports patzer.gabriel;
}